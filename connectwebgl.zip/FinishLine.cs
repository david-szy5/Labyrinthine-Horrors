using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using static SendToGoogle;

public class FinishLine : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject endGameTextObject;
    public TextMeshProUGUI endGameText;
    public SendToGoogle sender;

    void Start()
    {
        endGameTextObject.SetActive(false);
        //sender = new SendToGoogle();
        
    }

    void OnTriggerEnter(Collider other) 
    {
        Debug.Log("In OnTriggerEnter");
        // ..and if the GameObject you intersect has the tag 'Pick Up' assigned to it..
        // if (other.gameObject.CompareTag("FinishLineCube"))
        // {
        //     Debug.Log("FinishLine Detected");
        //     //SetEndGameText();
        // }
        sender.setCheckpoint(4);
        sender.setEndType(1);
        sender.Send();
        Debug.Log("At end of function");
    }

    void SetEndGameText() {
        endGameText.text = "Game Over";
        endGameTextObject.SetActive(true);
    }
}
